# 3200_assignment_6

### Instructions
```
Commands to run (Debian):

cd queries
npm i

sudo systemctl start mongodb

sudo systemctl start redis-server


node {file}.js
```


### AI DISCLAIMER
To familiarize myself with the redis js package, atop reading official docs, I had (web) Opus 4.6 make a quick cheatsheet. I included it i this project (CHEATSHEET.md).
